<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logowanie</title>
    <link rel="stylesheet" href="forum.css"/>
</head>
<body>
    <div class="header_left">
    <h3>Nieograniczony kontakt władcą kremówek!</h3>
    </div>
    <div class="header_right">
    <img src = "papa.png" alt="jak najbardziej"/>


    </div>
    <div class="main_left">
        <table>
    <tr><td align="center" colspan="3"><b>Nasze specjały:</b></td></tr>
        <?php
        $conn = @new mysqli("localhost", "root", "", "jan");
        if(@$conn->connect_errno!=0)
        {
            echo "Oj papa Jan będzie zły!" . $conn->connect_errno;
        }
        else
        {
            $qr = "SELECT nazwa, cena, ilosc FROM ZASOBY";
            $qr_send = $conn->query($qr);

            while($qr_result = $qr_send->fetch_assoc())
            {
                $out = $qr_result;

                $nazwa = $out['nazwa'];
                $cena = $out['cena'];
                $ilosc = $out['ilosc'];

                echo <<<end
                <tr><td>$nazwa</td> <td>$cena</td> <td>$ilosc</td></tr>
                end;

            }
            $conn->close();
        }
        ?>
        </table>

    </div>
        <div class="main_right">
        </div>
        
    <div class="footer_left">
    <p>- CZY PAPIEŻ LUBI MAŁE DZIEWCZYNKI Z WARKOCZYKAMI?<p>
        <p>- Z warkoczykami... albo bez warkoczyków... też ujdą</p>
<p><b><i>Paież Polak ~ 8 luty 2014</i></b></p>


    </div>

<div class="footer_right">
<h4>In Memoriam</h4>
<hr><br>
<a href="https://www.youtube.com/watch?v=2yusdx60_aw">Pieśń na cześć papieża... Karola Wojtyły:</a>
</div>
       

</body>
</html>


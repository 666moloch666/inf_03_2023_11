<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rejestruj</title>
    <link rel="stylesheet" href="rejestracja.css"/>
</head>
<body>
    <header>
        <h2>Stwórz swoje konto!</h2>
    </header>
    <main>
    <div class="main_left">
       
    </div>
    <div class="main_right">
        <form method="post">
            <table>
                <tr><td colspan="2" align="center"><h3>Utwórz konto w objęciach Jean'a Paula</h3></td></tr>
                <tr><td>Podaj login:</td><td><input type="text" name="login"/></td></tr>
                <tr><td>Podaj hasło:</td><td><input type="password" name="haslo"/></td></tr>
                <tr><td>Powtórz hasło:</td><td><input type="password" name="password_repeat"/></td></tr>
                <tr><td align="left"><input type="reset"/></td><td align="right"><input name="konto"type="submit"/></td></tr>
            </table>
        </form>
        <?php
        $conn = @new mysqli("localhost", "root", "", "jan");
        if($conn->connect_errno!=0)
        {
            echo "Pablo nie chce cię w swoim domu " . $conn->connect_errno;
        }
        else
        {
            
            if(isset($_POST['konto']) && !empty('login') && !empty('haslo') && !empty('password_repeat'))
            {
                $login = $_POST['login'];
                $haslo = $_POST['haslo'];
                $haslo_repeat = $_POST['password_repeat'];
                if($haslo != $haslo_repeat)
                {
                   
                    echo <<<end
                    <br>
                    <br>
                    <i> <p>„Człowiek jest wielki nie przez to, co posiada, lecz przez to, kim jest; <br>
                    nie przez to, co ma, lecz przez to, czym dzieli się z innymi. ”</p></i>
                    end;
                }
                else
                {

                    $qr = "INSERT INTO uzytkownicy values (NULL, '$login', '$haslo')";
                    $qr_send = @$conn->query($qr);

                    echo <<<end
                    <i><p>„Dłonie są krajobrazem serca. ”</p></i>

                    end;
                }
            }
            else
            {
                echo <<<end
                <br>
                <br>
                <i> <p>„Cała zewnętrzna konstytucja ciała kobiety, jego szczególny kształt, to właściwości,<br>
                 które mocą odwiecznej atrakcji stoją u początku poznania. ”</p></i>
                end;
            }
            $conn->close();
        }
        ?>
    </div>
    
</main>
    <footer>

<i>&copy; 1920-2005 jp2online.pl</i>
    </footer>
</body>
</html>
<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logowanie</title>
    <link rel="stylesheet" href="logowanie.css"/>
</head>
<body>
    <div class="header_left">
        <h2>Wstąp do naszego królestwa!</h2>
    </div>
    <div class="header_right">
        <img src="log.png"/>
    </div>
    <main>
        <form method="post">
            <table>
                <tr><td colspan="2" align="center"><h3>A jak Pan Bóg powiedział?</h3></td></tr>
                <tr><td>Podaj login:</td><td><input type="text" name="login"/></td></tr>
                <tr><td>Podaj hasło:</td><td><input type="password" name="haslo"/></td></tr>
                <tr><td align="left"><input type="reset"/></td><td align="right"><input name="konto"type="submit" value="Zaloguj"/></td></tr>
            </table>
        </form>
        <?php
        $conn = @new mysqli("localhost", "root", "", "jan");
        if($conn->connect_errno!=0)
        {
            echo "<i><p>Pablo nie chce cię w swoim domu!</p>
            <p>Precz szatanie!</p>
            </i> " . $conn->connect_errno;
        }
        else {
          
            if (isset($_POST['konto']) && !empty($_POST['haslo']) && !empty($_POST['login'])) 
            {
            
                $haslo = $_POST['haslo'];
                $login = $_POST['login'];

                
                $qr = "SELECT haslo, login FROM uzytkownicy where login='$login' and haslo='$haslo'";

$qr_send = $conn->query($qr);

if ($qr_send->num_rows == 0) {
header("Location: logowanie_repeat.php");
exit;
} else {
  header("Location: forum.php");
  exit;
}





            }
           else
           {
            echo<<<end
            <i><p>„Papież nie widział Cię jeszcze w swoim domu!” </p>
            <p>Precz szatanie!</p></i>
            end;

           }
           
            $conn->close();
        }
        ?>
    
    </div>
    
</main>
    <footer>

<i>&copy; 1920-2005 jp2online.pl</i>
    </footer>
</body>
</html>


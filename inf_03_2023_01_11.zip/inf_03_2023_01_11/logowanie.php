<!DOCTYPE html>
<html lang="pl-PL">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logowanie</title>
    <link rel="stylesheet" href="logowanie.css"/>
    <script>
    function change()
    {
        let result=document.getElementById("result");
        
         result.innerHTML='<img src="pablito_2.png" onclick="change_2()"/>';

   
        
    }
    function change_2()
    {
        let result=document.getElementById("result");
        
       result.innerHTML='<img src="pablito_1.png" onclick="change()"/>';
        
    }
</script>
</head>
<body>
    <div class="header_left">
        <h2>Wstąp do naszego królestwa!</h2>
    </div>
    <div class="header_right">
        <img  align="right" title ="Witaj moja kremóweczko!" src="kremowka.png"/>
    </div>
    <div class="main_left">
        <form method="post">
            <table>
                <tr><td colspan="2" align="center"><h3>A jak Pan Bóg powiedział?</h3></td></tr>
                <tr><td>Podaj login:</td><td><input type="text" name="login"/></td></tr>
                <tr><td>Podaj hasło:</td><td><input type="password" name="haslo"/></td></tr>
                <tr><td align="left"><input type="reset"/></td><td align="right"><input name="konto"type="submit" value="Zaloguj"/></td></tr>
            </table>
        </form>
        <?php
        $conn = @new mysqli("localhost", "root", "", "jan");
        if($conn->connect_errno!=0)
        {
            echo "<i><p>Pablo nie chce cię w swoim domu!</p>
            <p>Precz szatanie!</p>
            </i> " . $conn->connect_errno;
        }
        else {
          
            if (isset($_POST['konto']) && !empty($_POST['haslo']) && !empty($_POST['login'])) 
            {
            
                $haslo = $_POST['haslo'];
                $login = $_POST['login'];

                
                $qr = "SELECT haslo, login FROM uzytkownicy where login='$login' and haslo='$haslo'";

$qr_send = $conn->query($qr);

if ($qr_send->num_rows == 0) {
header("Location: logowanie_repeat.php");
exit;
} else {
  header("Location: forum.php");
  exit;
}





            }
           else
           {
            echo<<<end
            <i><p>„Dla chrześcijanina sytuacja nigdy nie jest beznadziejna. ”</p></i>
            end;

           }
           
            $conn->close();
        }
        ?>
    
    </div>
        <div class="main_right"  >
            <div class="photo">
               <span> id="result"> <img  src="pablito_1.png" id="kolor" onclick="change()"/>
            </span>
        </div>
        </div>
        <footer>
<i>&copy; 1920-2005 jp2online.pl</i>
    </footer>
</body>
</html>

